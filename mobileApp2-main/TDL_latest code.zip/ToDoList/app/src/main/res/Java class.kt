class Java
class {
}