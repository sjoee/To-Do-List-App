package com.example.to_do_list;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class NotesAdapter extends ArrayAdapter<MainActivity.Note> {
    private ArrayList<MainActivity.Note> notes;
    private ArrayList<MainActivity.Note> filteredNotes;
    private int longPressedPosition = -1;

    public NotesAdapter(Context context, ArrayList<MainActivity.Note> notes) {
        super(context, 0, notes);
        this.notes = notes;
        this.filteredNotes = new ArrayList<>(notes);
    }

    @Override
    public int getCount() {
        return filteredNotes.size();
    }

    @Override
    public MainActivity.Note getItem(int position) {
        return filteredNotes.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.note_item, parent, false);
        }
        MainActivity.Note note = getItem(position);
        TextView textViewHeader = convertView.findViewById(R.id.textViewHeader);
        TextView textViewParagraph = convertView.findViewById(R.id.textViewParagraph);
        final Button buttonDelete = convertView.findViewById(R.id.buttonDelete);

        textViewHeader.setText(note.getHeader());
        textViewParagraph.setText(note.getParagraph());

        // Show or hide the delete button based on the longPressedPosition
        buttonDelete.setVisibility(position == longPressedPosition ? View.VISIBLE : View.GONE);

        // Handle delete button click
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notes.remove(position);
                filteredNotes.remove(position);
                notifyDataSetChanged();
                longPressedPosition = -1; // Reset longPressedPosition
            }
        });

        // Handle long press to show delete button
        convertView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                longPressedPosition = position;
                notifyDataSetChanged();
                return true;
            }
        });

        // Hide the delete button if the note item is clicked again (optional)
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (longPressedPosition == position) {
                    longPressedPosition = -1;
                    notifyDataSetChanged();
                }
            }
        });

        return convertView;
    }

    @Override
    public void notifyDataSetChanged() {
        filteredNotes.clear();
        filteredNotes.addAll(notes);
        super.notifyDataSetChanged();
    }

    public void filterNotes(String query) {
        filteredNotes.clear();
        if (query.isEmpty()) {
            filteredNotes.addAll(notes);
        } else {
            for (MainActivity.Note note : notes) {
                if (note.getHeader().toLowerCase().contains(query.toLowerCase())) {
                    filteredNotes.add(note);
                }
            }
        }
        super.notifyDataSetChanged();
    }
}
