package com.example.to_do_list;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import android.view.View.OnLongClickListener;


public class MainActivity extends AppCompatActivity {

    private ArrayList<Note> notes;
    private NotesAdapter notesAdapter;
    private ListView listViewNotes;
    private EditText editTextHeader, editTextParagraph, editTextSearch;
    private Button buttonShowInputFields, buttonDone;
    private int editingNoteIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextSearch = findViewById(R.id.editTextSearch);
        editTextHeader = findViewById(R.id.editTextHeader);
        editTextParagraph = findViewById(R.id.editTextParagraph);
        listViewNotes = findViewById(R.id.listViewTasks);
        buttonShowInputFields = findViewById(R.id.buttonShowInputFields);
        buttonDone = findViewById(R.id.buttonDone);

        notes = new ArrayList<>();
        notesAdapter = new NotesAdapter(this, notes);
        listViewNotes.setAdapter(notesAdapter);

        buttonShowInputFields.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextHeader.setVisibility(View.VISIBLE);
                editTextParagraph.setVisibility(View.VISIBLE);
                buttonDone.setVisibility(View.VISIBLE);
                buttonShowInputFields.setVisibility(View.GONE);
            }
        });

        buttonDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String header = editTextHeader.getText().toString();
                String paragraph = editTextParagraph.getText().toString();
                if (!header.isEmpty() && !paragraph.isEmpty()) {
                    if (editingNoteIndex == -1) {
                        notes.add(new Note(header, paragraph));
                        Toast.makeText(MainActivity.this, "New note has been added to the list!", Toast.LENGTH_SHORT).show();
                    } else {
                        notes.set(editingNoteIndex, new Note(header, paragraph));
                        editingNoteIndex = -1;
                    }
                    notesAdapter.notifyDataSetChanged();
                    editTextHeader.setText("");
                    editTextParagraph.setText("");
                    editTextHeader.setVisibility(View.GONE);
                    editTextParagraph.setVisibility(View.GONE);
                    buttonDone.setVisibility(View.GONE);
                    buttonShowInputFields.setVisibility(View.VISIBLE);
                }
            }
        });

        listViewNotes.setOnItemLongClickListener((parent, view, position, id) -> {
            notes.remove(position);
            notesAdapter.notifyDataSetChanged();
            return true;
        });

        listViewNotes.setOnItemClickListener((parent, view, position, id) -> {
            Note note = notes.get(position);
            editTextHeader.setText(note.getHeader());
            editTextParagraph.setText(note.getParagraph());
            editTextHeader.setVisibility(View.VISIBLE);
            editTextParagraph.setVisibility(View.VISIBLE);
            buttonDone.setVisibility(View.VISIBLE);
            buttonShowInputFields.setVisibility(View.GONE);
            editingNoteIndex = position;
        });

        editTextSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                notesAdapter.filterNotes(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    static class Note {
        private String header;
        private String paragraph;

        public Note(String header, String paragraph) {
            this.header = header;
            this.paragraph = paragraph;
        }

        public String getHeader() {
            return header;
        }

        public String getParagraph() {
            return paragraph;
        }
    }

    private static class NotesAdapter extends ArrayAdapter<Note> {
        private ArrayList<Note> notes;
        private ArrayList<Note> filteredNotes;

        public NotesAdapter(MainActivity context, ArrayList<Note> notes) {
            super(context, 0, notes);
            this.notes = notes;
            this.filteredNotes = new ArrayList<>(notes);
        }

        @Override
        public int getCount() {
            return filteredNotes.size();
        }

        @Override
        public Note getItem(int position) {
            return filteredNotes.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.note_item, parent, false);
            }
            Note note = getItem(position);
            TextView textViewHeader = convertView.findViewById(R.id.textViewHeader);
            TextView textViewParagraph = convertView.findViewById(R.id.textViewParagraph);
            textViewHeader.setText(note.getHeader());
            textViewParagraph.setText(note.getParagraph());
            return convertView;
        }

        @Override
        public void notifyDataSetChanged() {
            // Update filteredNotes with the latest notes
            filteredNotes.clear();
            filteredNotes.addAll(notes);
            super.notifyDataSetChanged();
        }

        public void filterNotes(String query) {
            filteredNotes.clear();
            if (query.isEmpty()) {
                filteredNotes.addAll(notes);
            } else {
                for (Note note : notes) {
                    if (note.getHeader().toLowerCase().contains(query.toLowerCase())) {
                        filteredNotes.add(note);
                    }
                }
            }
            notifyDataSetChanged();
        }
    }
}